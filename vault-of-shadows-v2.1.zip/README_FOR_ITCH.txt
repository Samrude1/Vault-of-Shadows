VAULT OF SHADOWS - DEPLOYMENT FILES
==================================

This folder contains all the files needed to deploy "Vault Of Shadows" on itch.io.

GAME FILES:
-----------
- index.html (main game file - upload this as your HTML embed)
- css/style.css (game styling)
- js/ (all JavaScript modules)

DEPLOYMENT INSTRUCTIONS:
-----------------------
1. Upload index.html as your main game file on itch.io
2. Make sure to set the game as "HTML" type
3. The game will run entirely in the browser - no server needed
4. Test the game thoroughly after uploading

GAME FEATURES:
-------------
- Turn-based dungeon crawler
- 8 unique monster types
- Fog of war exploration
- Sound system with controls
- Hunger survival mechanics
- Magical scroll system
- Procedurally generated dungeons
- Multiple levels with win condition

TECHNICAL NOTES:
---------------
- Built with vanilla JavaScript, HTML5 Canvas
- No external dependencies
- Web Audio API for sound
- localStorage for settings persistence
- Responsive design works on desktop and mobile

VERSION: 2.1 (Latest stable release)

For more information, see the main README.md in the parent directory.
