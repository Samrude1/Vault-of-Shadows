# PHASE 3: Commercial Release & Mechanics Overhaul

**Goal**: Transform "Vault of Shadows" into a commercially viable, replayable roguelike with deep mechanics supporting 2-3 hour runs.

## 1. Mechanics Overhaul (The "Long Game" Update) - ✅ Complete

To support a Save System and deeper runs (Level 25+), we must fix the scaling issues where players become invincible.

### A. XP & Leveling Curve (Anti-God Mode) - ✅ Done
**Current**: Exponential Curve with 1.12 exponent (adjusted from 1.15).
- Formula: `XP_Next = Math.floor(50 * Math.pow(1.12, Level))`
- **Impact**: Leveling slows down significantly after Level 10, making every level up feel impactful and earned.
- **Level Cap**: Increased from 15 to **100** for endless mode support.

### B. Monster Scaling (The "Deadly Depths") - ✅ Done
Monsters currently scale too slowly. We will implement **Percentage-Based Scaling** and **Tiers**.

1.  **Stat Scaling**:
    - **HP**: `BaseHP * (1 + (Level * 0.15))` -> 15% HP increase per level.
    - **Attack**: `BaseAtk + Math.floor(Level * 0.4)` -> Keeps pace with player armor.
    - **Defense**: `BaseDef + Math.floor(Level * 0.2)` -> Prevents player from one-shotting everything.

2.  **Monster Tiers (New Mechanic)**:
    - **Level 10+**: 20% chance for **"Veteran"** prefix (+30% Stats, XP x1.5).
    - **Level 20+**: 15% chance for **"Elite"** prefix (+60% Stats, XP x2, +1 Drop Roll).
    - **Level 30+**: 10% chance for **"Champion"** prefix (+100% Stats, XP x3, Guaranteed Item).

3.  **Progressive Monster Types (Every 3 Levels)**:
    - **Levels 1-3**: Weak monsters only (Kobold, Bat, Goblin)
    - **Levels 4-6**: Medium monsters introduced (Orc, Skeleton) + some weak
    - **Levels 7-9**: Strong monsters (Troll, Zombie) + some medium
    - **Levels 10+**: Deadly monsters (Dragon) + strong monsters

### C. Player Stat Scaling & Balance - ✅ Done
- **Increased Stat Gains**: +3 HP, +1 Attack, +1 Defense per level (was +2 HP, +0.5 Atk/Def).
- **Percentage Bonuses**: Every 10 levels, gain +10% Max HP and +5% Attack/Defense.
- **Equipment Scaling**: Weapons/armor found on deeper levels have bonus stats (+0.15 Atk/level, +0.1 Def/level).
- **XP Curve Adjustment**: Reduced from 1.15 to 1.12 for smoother progression.

---

## 2. Core Systems (Critical for Release)
- [ ] **Save & Load System**
    - Implement `localStorage` saving for current run state (Player, Dungeon, Monsters, Items).
    - Auto-save on floor transition.
    - "Continue" button on main menu.
- [ ] **Settings & Accessibility**
    - Key remapping support.
    - Granular volume sliders (Music/SFX).
- [ ] **Tutorial / Onboarding**
    - Interactive first-level tutorial or "Help" overlay.

## 3. Gameplay Depth (Replayability)
- [ ] **Character Classes**
    - **Warrior**: Starts with Sword + Chainmail, +2 HP/Lvl.
    - **Rogue**: Starts with Dagger + Cloak, +5% Crit/Lvl.
    - **Mage**: Starts with Staff + Scroll, +1 Spell Dmg/Lvl.
- [ ] **Persistent Progression**
    - **High Score Board**: Local top 10 runs.
    - **Unlockables**: Unlock "Mage" class by finding a Spellbook.

## 4. Content Expansion
- [ ] **Win Condition**: Move Amulet of Yendor to **Level 25**.
- [ ] **Biomes**:
    - **Sewers (Lvl 1-5)**: Rats, Slimes.
    - **Dungeon (Lvl 6-15)**: Orcs, Skeletons.
    - **Deep Halls (Lvl 16-25)**: Dragons, Demons, Liches.

## 5. Visual & Audio Polish
- [ ] **Particle Effects 2.0**: Blood splatters, level-up fireworks.
- [ ] **Dynamic Lighting**: Torches on walls.


---

## Recent Completions (Latest Session)

### ✅ Critical Balance Fixes (v3.1)
- **Removed Level Cap**: Players can now level to 100 (was capped at 15, causing impossible difficulty at deep levels).
- **Increased Stat Gains**: +3 HP, +1 Atk, +1 Def per level (was +2 HP, +0.5 Atk/Def).
- **Percentage Bonuses**: Every 10 levels, gain +10% Max HP and +5% Attack/Defense for exponential scaling.
- **Equipment Level Scaling**: 
  - Weapons: +0.15 Attack per dungeon level
  - Armor: +0.1 Defense per dungeon level
  - Example: Level 50 Sword = +9 Attack (was +2)
- **XP Curve Adjustment**: Reduced from 1.15 to 1.12 exponent for 68% less grind at Level 50.

**Impact**: Game is now balanced for endless progression. Players can survive deep dungeons (Level 30-50+) with proper strategy and equipment.

### ✅ Shop System Improvements
- Removed weak early-game items (Dagger, Leather Armor) from shop inventory.
- Shop now starts with Sword and Chain Mail as minimum tier equipment.
- Added **Shield Potion** and **Strength Potion** as purchasable items.

### ✅ New Carryable Potions
- **Shield Potion**: +50% Defense for 10 turns (40 gold).
- **Strength Potion**: +50% Attack for 10 turns (40 gold).
- Both potions are inventory items (like scrolls) and can be carried and used strategically.

### ✅ Scroll Effectiveness Improvements
- **Scroll of Freeze**: Duration increased from 2 → **5 turns**, now shows enemy count.
- **Scroll of Haste**: Duration increased from 10 → **15 turns**.
- **Scroll of Summon**: Now attacks **ALL nearby enemies** (within 5 tiles) for **20 damage each** (was single target, 15 damage).
- **Scroll of Identify**: Now reveals all items on the floor, even through fog of war.

### ✅ Visual & Audio Enhancements
- **Critical Hit Feedback**: 
  - Screen shake effect (5 intensity for player, 10 for enemies).
  - Color flash overlay (white for player crits, red for enemy crits).
  - Unique critical hit sound effect.
- **Procedural Wall Colors**: 
  - Levels 1-3 remain classic gray.
  - Every 3 levels after that features a unique color using Golden Angle distribution.
  - Ensures visual variety while maintaining readability.

### ✅ Critical Bug Fixes
- **Fixed Double-Attack Bug**: Monsters were attacking twice per turn due to counterattack system + regular turn. Removed counterattack system entirely for fair, turn-based combat.
- **Fixed UI Layout**: Inventory display no longer wraps to next line with long item names.
- **Fixed NaN Stats Bug**: Resolved issue where equipment scaling caused "NaN" (Not a Number) errors in deep dungeon levels.

---

## Priority Order
1. **Mechanics Overhaul** (Fix scaling first, otherwise long runs are boring) - ✅ Complete
2. **Save/Load System** (Essential for Level 25 runs)
3. **Character Classes** (Replayability)
4. **Content Expansion** (Biomes)
