// GameRooms.js - Special room handling
class GameRooms {
    constructor(game) {
        this.game = game;
    }

    populateSpecialRooms() {
        const specialRoomsFound = [];

        this.game.dungeon.rooms.forEach(room => {
            if (room.type === 'normal') return;

            const centerX = room.x + Math.floor(room.width / 2);
            const centerY = room.y + Math.floor(room.height / 2);

            // Track special room types found
            if (!specialRoomsFound.includes(room.type)) {
                specialRoomsFound.push(room.type);
            }

            switch (room.type) {
                case 'treasure':
                    const numTreasureItems = 3 + Math.floor(Math.random() * 3);
                    for (let i = 0; i < numTreasureItems; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const itemTypes = ['health_potion', 'sword', 'axe', 'plate_armor', 'magic_staff'];
                        const type = itemTypes[Math.floor(Math.random() * itemTypes.length)];
                        this.game.items.push(new Item(pos.x, pos.y, type, null, this.game.currentLevel));
                    }
                    for (let i = 0; i < 2; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const eliteTypes = ['orc', 'troll'];
                        const type = eliteTypes[Math.floor(Math.random() * eliteTypes.length)];
                        this.game.monsters.push(new Monster(pos.x, pos.y, type, this.game.currentLevel));
                    }
                    break;

                case 'trap':
                    // Place a tempting item in the center
                    const trapScrolls = ['scroll_fireball', 'scroll_freeze', 'scroll_haste', 'scroll_mapping'];
                    const scrollType = trapScrolls[Math.floor(Math.random() * trapScrolls.length)];
                    this.game.items.push(new Item(centerX, centerY, scrollType, null, this.game.currentLevel));

                    // Surround the item with hidden traps
                    // 50% chance for each tile in the room to be a trap (except the item itself)
                    for (let y = room.y + 1; y < room.y + room.height - 1; y++) {
                        for (let x = room.x + 1; x < room.x + room.width - 1; x++) {
                            if (x === centerX && y === centerY) continue; // Don't trap the item itself

                            // Ensure trap is on a walkable floor tile
                            if (this.game.dungeon.isWalkable(x, y) && Math.random() < 0.4) {
                                const trapTypes = ['spikes', 'poison', 'summon', 'teleport'];
                                const trapType = trapTypes[Math.floor(Math.random() * trapTypes.length)];
                                this.game.traps.push({ x, y, type: trapType, triggered: false });
                            }
                        }
                    }

                    // Add some visible monsters too
                    const numTrapMonsters = 1 + Math.floor(Math.random() * 2);
                    for (let i = 0; i < numTrapMonsters; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const type = this.game.combat.selectMonsterType(this.game.currentLevel);
                        this.game.monsters.push(new Monster(pos.x, pos.y, type, this.game.currentLevel));
                    }
                    break;

                case 'nest':
                    const numNestMonsters = 3 + Math.floor(this.game.currentLevel * 0.5);
                    for (let i = 0; i < numNestMonsters; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const type = this.game.combat.selectMonsterType(this.game.currentLevel);
                        this.game.monsters.push(new Monster(pos.x, pos.y, type, this.game.currentLevel));
                    }
                    for (let i = 0; i < 2; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const goldAmount = 10 + Math.floor(Math.random() * 20);
                        this.game.items.push(new Item(pos.x, pos.y, 'gold', goldAmount, this.game.currentLevel));
                    }
                    break;

                case 'shrine':
                    this.game.items.push(new Item(centerX, centerY, 'shrine', null, this.game.currentLevel));
                    break;

                case 'library':
                    const numLibraryScrolls = 2 + Math.floor(Math.random() * 2);
                    for (let i = 0; i < numLibraryScrolls; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const scrollTypes = ['scroll_teleport', 'scroll_magic_missile', 'scroll_healing', 'scroll_enchantment', 'scroll_fireball', 'scroll_freeze', 'scroll_haste', 'scroll_identify', 'scroll_mapping', 'scroll_summon'];
                        const type = scrollTypes[Math.floor(Math.random() * scrollTypes.length)];
                        this.game.items.push(new Item(pos.x, pos.y, type, null, this.game.currentLevel));
                    }
                    const numSkeletons = 2 + Math.floor(Math.random() * 2);
                    for (let i = 0; i < numSkeletons; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        this.game.monsters.push(new Monster(pos.x, pos.y, 'skeleton', this.game.currentLevel));
                    }
                    break;

                case 'armory':
                    const armoryItems = ['sword', 'axe', 'mace', 'plate_armor', 'chain_mail'];
                    for (let i = 0; i < 2; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        const type = armoryItems[Math.floor(Math.random() * armoryItems.length)];
                        this.game.items.push(new Item(pos.x, pos.y, type, null, this.game.currentLevel));
                    }
                    const numOrcs = 2 + Math.floor(Math.random() * 2);
                    for (let i = 0; i < numOrcs; i++) {
                        const pos = this.getRandomPosInRoom(room);
                        this.game.monsters.push(new Monster(pos.x, pos.y, 'orc', this.game.currentLevel));
                    }
                    break;
            }
        });

        // Display a single summary message for special rooms found
        if (specialRoomsFound.length > 0) {
            const roomMessages = {
                'treasure': '💎 Treasure',
                'trap': '⚠️ Trap',
                'nest': '👹 Monster Nest',
                'shrine': '✨ Shrine',
                'library': '📚 Library',
                'armory': '⚔️ Armory'
            };
            const foundRooms = specialRoomsFound.map(type => roomMessages[type]).join(', ');
            this.game.addMessage(`Special rooms detected: ${foundRooms}`);
        }
    }

    getRandomPosInRoom(room) {
        const x = room.x + 1 + Math.floor(Math.random() * (room.width - 2));
        const y = room.y + 1 + Math.floor(Math.random() * (room.height - 2));
        return { x, y };
    }
}
