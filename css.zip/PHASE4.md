# PHASE 4: Endless Dungeon Crawler - Goal System Redesign

**Vision**: Transform "Vault of Shadows" from a traditional "find the amulet" roguelike into a modern endless dungeon crawler focused on high scores, replayability, and infinite progression.

---

## 🎯 Core Philosophy Change

### **Old System (Classic Rogue)**
- Linear goal: Find Amulet of Yendor on Level 10
- Return to surface to "win"
- Game ends after victory
- Limited replayability

### **New System (Modern Endless Roguelike)**
- **No final goal** - survive as long as possible
- **Endless descent** - go deeper until you die
- **High score focus** - compete with yourself and others
- **Infinite replayability** - every run is a new challenge

---

## 📋 Implementation Roadmap

### **✅ Completed Tasks**
- **Fixed Critical Bug**: Resolved "NaN" errors in player stats and combat caused by item scaling logic.
- **Item Scaling**: Updated `Item` class to correctly track dungeon depth for stat calculations.

### **Phase 4.1: Remove Legacy Amulet System** ⏳ Pending
**Goal**: Clean up the old win condition and prepare for endless mode.

**Tasks**:
- [ ] Remove Amulet of Yendor item from game
- [ ] Remove Amulet Guardian boss (or repurpose as Level 10 boss)
- [ ] Remove "return to surface" win condition logic
- [ ] Remove `hasAmulet` flag and related checks
- [ ] Update game over screen to show "Depth Reached" instead of "Victory/Defeat"

**Files to Modify**:
- `js/game.js`: Remove amulet spawn logic, win condition checks
- `js/item.js`: Remove amulet item definition
- `js/monster.js`: Remove or repurpose Amulet Guardian
- `js/GameCombat.js`: Remove amulet-related boss logic

---

### **Phase 4.2: Milestone System** ⏳ Pending
**Goal**: Give players meaningful progression markers as they descend.

**Milestone Levels**:
- **Level 10**: "Novice Delver" 🎖️
  - Message: "You've conquered the upper dungeons! The depths await..."
  - Reward: +5 Max HP, +1 All Stats
  
- **Level 25**: "Master Explorer" 🏆
  - Message: "Few have ventured this deep. You are among the elite!"
  - Reward: +10 Max HP, +2 All Stats, Guaranteed Legendary Item
  
- **Level 50**: "Legend of the Depths" 👑
  - Message: "You have become a legend. The abyss trembles before you!"
  - Reward: +20 Max HP, +3 All Stats, Unlock Ascension Mode
  
- **Level 75**: "Immortal" ⭐
  - Message: "You have transcended mortality itself!"
  - Reward: +30 Max HP, +5 All Stats
  
- **Level 100**: "God of the Dungeon" 💎
  - Message: "You are eternal. Nothing can stop you now."
  - Reward: +50 Max HP, +10 All Stats, Permanent Haste

**Implementation**:
- [ ] Create milestone tracking system
- [ ] Add milestone messages and visual effects
- [ ] Implement milestone rewards (stat boosts, items)
- [ ] Add milestone indicators to UI

---

### **Phase 4.3: High Score System** ⏳ Pending
**Goal**: Track player achievements and create competition.

**Metrics to Track**:
- **Deepest Level Reached** (primary score)
- **Total Gold Collected**
- **Monsters Killed**
- **Bosses Defeated**
- **Time Survived** (in turns)
- **Final Player Level**

**Features**:
- [ ] Save high scores to `localStorage`
- [ ] Track top 10 runs locally
- [ ] Display high score on game over screen
- [ ] Show "New Record!" message when beating previous best
- [ ] Add "Hall of Fame" screen accessible from main menu

**Data Structure**:
```javascript
{
  runs: [
    {
      id: "run_timestamp",
      depth: 42,
      gold: 5420,
      kills: 312,
      bosses: 8,
      turns: 2450,
      playerLevel: 18,
      date: "2024-01-15",
      class: "Warrior" // Future: when classes are added
    }
  ]
}
```

---

### **Phase 4.4: Leaderboard UI** ⏳ Pending
**Goal**: Create a compelling UI to showcase achievements.

**Leaderboard Screen**:
- [ ] New "Hall of Fame" button on main menu
- [ ] Display top 10 runs in a table format
- [ ] Show rank, depth, gold, kills, date
- [ ] Highlight current run if it made the leaderboard
- [ ] Add "Clear Scores" button (with confirmation)

**Game Over Screen Updates**:
- [ ] Show "Depth Reached: XX" prominently
- [ ] Display run statistics (gold, kills, bosses, turns)
- [ ] Show if run made the leaderboard (rank #X)
- [ ] Add "New Record!" animation if deepest run

---

### **Phase 4.5: Biome System** ⏳ Pending
**Goal**: Add visual variety and thematic progression as players descend.

**Biome Tiers** (Every 10-15 levels):
1. **Levels 1-10**: "The Sewers" 🟤
   - Gray/brown walls
   - Rats, Slimes, Kobolds
   - Damp, claustrophobic feel

2. **Levels 11-25**: "The Dungeons" 🟦
   - Blue-gray stone walls
   - Orcs, Skeletons, Trolls
   - Classic dungeon aesthetic

3. **Levels 26-40**: "The Deep Halls" 🟣
   - Purple/dark stone walls
   - Dragons, Liches, Demons
   - Ancient, mystical atmosphere

4. **Levels 41-60**: "The Abyss" 🔴
   - Red/black volcanic walls
   - Fire Elementals, Hellhounds, Archdemons
   - Hellish, dangerous environment

5. **Levels 61-80**: "The Void" ⚫
   - Black/void walls with stars
   - Void Creatures, Cosmic Horrors
   - Otherworldly, alien feel

6. **Levels 81+**: "The Infinite" ✨
   - Shifting rainbow/prismatic walls
   - Ascended Beings, Time Wraiths
   - Reality-bending, transcendent

**Implementation**:
- [ ] Extend wall color system to support biome-specific palettes
- [ ] Add biome transition messages
- [ ] Create biome-specific monster pools
- [ ] Add biome-specific loot tables

---

### **Phase 4.6: Ascension Mode** ⏳ Pending
**Goal**: Add a "New Game+" difficulty for veteran players.

**Unlock Condition**: Reach Level 50 at least once

**Ascension Modifiers**:
- **Enemies**: +50% HP, +30% Attack, +20% Defense
- **Loot**: +100% gold drops, +50% item quality
- **XP**: +200% XP gain (faster leveling)
- **Special**: Guaranteed Elite/Champion monsters every floor
- **Leaderboard**: Separate "Ascension" leaderboard

**Features**:
- [ ] Add "Ascension Mode" toggle on new game screen
- [ ] Implement ascension stat modifiers
- [ ] Add "Ascension" badge to leaderboard entries
- [ ] Create separate ascension high scores

---

## 🎨 UI/UX Improvements

### **Main Menu Updates**
- [ ] Add "Hall of Fame" button
- [ ] Show "Best Depth: XX" on main screen
- [ ] Add "Ascension Mode" toggle (if unlocked)

### **In-Game HUD**
- [ ] Add "Next Milestone: Level XX" indicator
- [ ] Show current biome name
- [ ] Display run statistics (kills, gold, turns)

### **Game Over Screen**
- [ ] Prominent "Depth Reached: XX" display
- [ ] Full run statistics breakdown
- [ ] Leaderboard placement (if applicable)
- [ ] "New Record!" celebration animation

---

## 📊 Success Metrics

After Phase 4 implementation, the game should have:
- ✅ **No artificial endpoint** - players can go as deep as they dare
- ✅ **Clear progression** - milestones every 10-25 levels
- ✅ **Competitive element** - high scores and leaderboards
- ✅ **Visual variety** - biomes change every 10-15 levels
- ✅ **Replayability** - every run is a new challenge
- ✅ **Endgame content** - Ascension mode for veterans

---

## 🚀 Implementation Priority

1. **Phase 4.1** (Remove Amulet) - **Critical** - Clean slate for new system
2. **Phase 4.2** (Milestones) - **High** - Immediate player engagement
3. **Phase 4.3** (High Scores) - **High** - Core endless mode feature
4. **Phase 4.4** (Leaderboard UI) - **Medium** - Polish for high scores
5. **Phase 4.5** (Biomes) - **Medium** - Visual variety for long runs
6. **Phase 4.6** (Ascension) - **Low** - Endgame content for veterans

---

## 🎯 Expected Outcome

After Phase 4, "Vault of Shadows" will be:
- A **modern endless roguelike** with infinite replayability
- Focused on **high scores** and **personal bests**
- Visually diverse with **6+ biomes**
- Competitive with **local leaderboards**
- Challenging with **Ascension mode** for veterans

**Tagline**: *"How deep can you go?"*
