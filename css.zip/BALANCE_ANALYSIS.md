# Balance Analysis: Player vs Monster Scaling

## 🚨 CRITICAL ISSUES FOUND

### **Issue #1: Player Level Cap at 15**
**Location**: `player.js` line 167
```javascript
while (this.xp >= this.xpToNextLevel && this.level < 15) {
```

**Problem**: Player stops leveling at Level 15, but can go to Level 50+ dungeons!

**Impact**:
- Player at Level 15 faces Level 50 monsters
- Level 50 monsters have **+735% HP**, **+19.6 Attack**, **+9.8 Defense**
- Player is completely outmatched

**Fix Required**: Remove level cap or increase to 100+

---

## 📊 Current Scaling Formulas

### **Player Scaling (Per Level)**
- **Max HP**: +2 per level
- **Attack**: +1 every 2 levels (0.5 avg/level)
- **Defense**: +1 every 2 levels (0.5 avg/level)
- **Level Cap**: 15 ❌

### **Monster Scaling (Per Dungeon Level)**
- **HP**: Base × (1 + (Level - 1) × 0.15) = **+15% per level**
- **Attack**: Base + (Level - 1) × 0.4 = **+0.4 per level**
- **Defense**: Base + (Level - 1) × 0.2 = **+0.2 per level**
- **No Level Cap**: ✅

### **XP Curve (Exponential)**
```javascript
XP_Next = 50 × (1.15 ^ Level)
```
- Level 1 → 2: 57 XP
- Level 5 → 6: 100 XP
- Level 10 → 11: 202 XP
- Level 15 → 16: 407 XP
- Level 20 → 21: 818 XP

---

## 🧮 Mathematical Simulation

### **Scenario 1: Level 15 Player vs Level 15 Dungeon**

**Player Stats (Level 15)**:
- HP: 20 + (15 × 2) = **50 HP**
- Attack: 4 + (15 ÷ 2) = **11.5 Attack** (rounded to 11 or 12)
- Defense: 2 + (15 ÷ 2) = **9.5 Defense** (rounded to 9 or 10)

**Orc Stats (Level 15 Dungeon)**:
- Base: 15 HP, 4 Atk, 2 Def
- Scaled: 15 × (1 + 14 × 0.15) = **45 HP**
- Attack: 4 + (14 × 0.4) = **9.6 Attack**
- Defense: 2 + (14 × 0.2) = **4.8 Defense**

**Analysis**: ✅ **Balanced** - Player slightly stronger

---

### **Scenario 2: Level 15 Player vs Level 30 Dungeon** ❌

**Player Stats (CAPPED at Level 15)**:
- HP: **50 HP**
- Attack: **11-12**
- Defense: **9-10**

**Orc Stats (Level 30 Dungeon)**:
- HP: 15 × (1 + 29 × 0.15) = **80 HP** (+60% vs player)
- Attack: 4 + (29 × 0.4) = **15.6 Attack** (+30% vs player)
- Defense: 2 + (29 × 0.2) = **7.8 Defense** (-20% vs player)

**Elite Orc (25% chance at Level 30)**:
- HP: 80 × 1.6 = **128 HP** (+156% vs player!)
- Attack: 15.6 × 1.3 = **20.3 Attack** (+70% vs player!)
- Defense: 7.8 + 1 = **8.8 Defense**

**Analysis**: ❌ **SEVERELY UNBALANCED** - Player gets destroyed

---

### **Scenario 3: Level 15 Player vs Level 50 Dungeon** ❌❌❌

**Player Stats (CAPPED at Level 15)**:
- HP: **50 HP**
- Attack: **11-12**
- Defense: **9-10**

**Dragon Stats (Level 50 Dungeon)**:
- Base: 40 HP, 10 Atk, 5 Def
- HP: 40 × (1 + 49 × 0.15) = **334 HP** (+568% vs player!)
- Attack: 10 + (49 × 0.4) = **29.6 Attack** (+150% vs player!)
- Defense: 5 + (49 × 0.2) = **14.8 Defense** (+50% vs player)

**Champion Dragon (10% chance at Level 50)**:
- HP: 334 × 2.0 = **668 HP** (+1236% vs player!!!)
- Attack: 29.6 × 1.5 = **44.4 Attack** (+270% vs player!!!)
- Defense: 14.8 + 2 = **16.8 Defense**

**Combat Simulation**:
- Player damage to Dragon: 11 + 1d6 - 14.8 = **~2-3 damage per hit**
- Dragon damage to Player: 29.6 + 1d6 - 9.5 = **~24-29 damage per hit**
- **Player dies in 2 hits, Dragon survives 100+ hits**

**Analysis**: ❌❌❌ **IMPOSSIBLE** - Player has 0% chance

---

## 🎯 Recommended Fixes

### **Fix #1: Remove Player Level Cap** (CRITICAL)
```javascript
// OLD (player.js line 167)
while (this.xp >= this.xpToNextLevel && this.level < 15) {

// NEW
while (this.xp >= this.xpToNextLevel && this.level < 100) {
```

**Rationale**: Allow player to level up to match dungeon depth

---

### **Fix #2: Adjust Player Stat Gains**
Current gains are too slow for deep runs.

**Option A: Increase Flat Gains**
```javascript
// Current
this.maxHealth += 2;  // +2 HP/level
this.attack += 1;     // +0.5 avg/level
this.defense += 1;    // +0.5 avg/level

// Proposed
this.maxHealth += 3;  // +3 HP/level
this.attack += 1;     // +1 every level
this.defense += 1;    // +1 every level (alternating removed)
```

**Option B: Add Percentage Scaling (Like Monsters)**
```javascript
levelUp() {
    this.level++;
    
    // Base gains
    this.maxHealth += 3;
    this.attack += 1;
    this.defense += 1;
    
    // Percentage bonus every 10 levels
    if (this.level % 10 === 0) {
        this.maxHealth = Math.floor(this.maxHealth * 1.1); // +10%
        this.attack = Math.floor(this.attack * 1.05); // +5%
        this.defense = Math.floor(this.defense * 1.05); // +5%
    }
}
```

---

### **Fix #3: Equipment Scaling**
Add level-scaled equipment to help player keep up.

**Proposed**: Equipment found on deeper levels has better stats
```javascript
// Sword found on Level 1: +2 Attack
// Sword found on Level 20: +2 + (20 × 0.2) = +6 Attack
// Sword found on Level 50: +2 + (50 × 0.2) = +12 Attack
```

---

### **Fix #4: XP Curve Adjustment**
Current curve might be too steep for endless mode.

**Current**: `50 × (1.15 ^ Level)`
- Level 20: 818 XP needed
- Level 30: 3,313 XP needed
- Level 50: 45,517 XP needed (!)

**Proposed**: `50 × (1.12 ^ Level)` (slower growth)
- Level 20: 481 XP needed
- Level 30: 1,497 XP needed
- Level 50: 14,542 XP needed

**Rationale**: Players should be able to level up at a reasonable pace

---

## 📈 Balanced Scaling Targets

For a balanced endless mode, aim for these ratios:

### **Player vs Same-Level Monster**
- Player HP: **1.2-1.5× monster HP** (player should be tankier)
- Player Attack: **1.0-1.2× monster attack** (roughly equal)
- Player Defense: **1.0-1.2× monster defense** (roughly equal)

### **Player vs Elite Monster (Same Level)**
- Player HP: **0.8-1.0× elite HP** (elite should be tough)
- Player Attack: **0.9-1.1× elite attack** (challenging but fair)
- Player Defense: **0.9-1.1× elite defense** (challenging but fair)

### **Player vs Champion Monster (Same Level)**
- Player HP: **0.5-0.7× champion HP** (boss-level threat)
- Player Attack: **0.7-0.9× champion attack** (requires strategy)
- Player Defense: **0.7-0.9× champion defense** (requires strategy)

---

## ✅ Immediate Action Items

1. **CRITICAL**: Remove level 15 cap → set to 100
2. **HIGH**: Increase player stat gains per level
3. **HIGH**: Adjust XP curve from 1.15 to 1.12
4. **MEDIUM**: Add equipment level scaling
5. **LOW**: Add percentage bonuses every 10 levels

---

## 🧪 Testing Recommendations

After implementing fixes, test these scenarios:
- [ ] Level 15 player vs Level 15 dungeon (should be balanced)
- [ ] Level 30 player vs Level 30 dungeon (should be challenging)
- [ ] Level 50 player vs Level 50 dungeon (should be very hard but possible)
- [ ] Level 50 player vs Champion Dragon (should require perfect play)

**Success Criteria**: Player can survive and progress at any level if skilled, but faces increasing challenge.
