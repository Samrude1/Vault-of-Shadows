1. Kobold King (Level 3)
Stats: HP: 30, ATK: 5, DEF: 2
Symbol: 'K', Color: '#f59e0b' (orange)
Special Ability: Summons 2 kobolds when HP < 50%
Behavior: Aggressive, always pursues player
Drops: 100-150 gold, guaranteed rare item (sword or chain mail)
XP: 150
2. Orc Warlord (Level 6)
Stats: HP: 50, ATK: 8, DEF: 4
Symbol: 'O', Color: '#dc2626' (red)
Special Ability: Enraged at HP < 30% (+2 ATK bonus)
Behavior: Aggressive, faster when enraged
Drops: 150-200 gold, guaranteed rare item (axe or plate armor)
XP: 250
3. Lich (Level 9)
Stats: HP: 60, ATK: 10, DEF: 3
Symbol: 'L', Color: '#8b5cf6' (purple)
Special Abilities:
Summons 2 skeletons every 3 turns
Teleports to random location when hit (20% chance)
Behavior: Tactical, maintains distance
Drops: 200-300 gold, guaranteed scroll + rare item
XP: 350
4. Ancient Dragon (Level 12)
Stats: HP: 100, ATK: 15, DEF: 6
Symbol: 'Ð', Color: '#dc2626' (dark red)
Special Abilities:
Area fire damage (3-tile radius, 5 damage)
Can fly over walls
Behavior: Aggressive, uses area attacks
Drops: 300-500 gold, legendary item
XP: 500
5. Amulet Guardian (Level 10)
Stats: HP: 80, ATK: 12, DEF: 5
Symbol: 'G', Color: '#fbbf24' (gold)
Special Ability: Shield (reduces damage by 50%) every other turn
Behavior: Guards the Amulet, aggressive
Drops: 250-400 gold, Amulet of Yendor
XP: 400
Boss Spawn Logic
Implementation in 
game.js
:

// In goToNextLevel() after dungeon generation
if (this.isBossLevel(this.currentLevel)) {
    this.spawnBoss(this.currentLevel);
}
isBossLevel(level) {
    return [3, 6, 9, 10, 12].includes(level);
}
spawnBoss(level) {
    const bossTypes = {
        3: 'kobold_king',
        6: 'orc_warlord',
        9: 'lich',
        10: 'amulet_guardian',
        12: 'ancient_dragon'
    };
    
    const bossType = bossTypes[level];
    const bossPos = this.dungeon.getBossSpawnPosition(); // Center of last room
    this.monsters.push(new Monster(bossPos.x, bossPos.y, bossType));
    this.addMessage(`⚠️ You feel a powerful presence... A boss awaits!`);
}
Boss AI in 
monster.js
:

Bosses always pursue player (no random movement)
Special abilities trigger based on HP thresholds or turn counters
Boss flag prevents normal monster behavior
2. Enhanced Combat Mechanics
Goal: Make combat more tactical with random elements and strategic choices.

2.1 Critical Hits
Implementation:

10% base chance for critical hit
Critical hits deal 2x damage
Display "CRITICAL!" message in bright color
// In player.js attackTarget()
attackTarget(target) {
    const baseDamage = Math.max(1, this.attack - target.defense + Math.floor(Math.random() * 3));
    const isCrit = Math.random() < 0.10; // 10% chance
    const damage = isCrit ? baseDamage * 2 : baseDamage;
    
    return {
        killed: target.takeDamage(damage),
        damage: damage,
        isCrit: isCrit
    };
}
2.2 Dodge Chance
Implementation:

Dodge chance = 5% per defense point (max 30%)
Dodged attacks deal 0 damage
Display "DODGED!" message
// In player.js takeDamage()
takeDamage(amount) {
    const dodgeChance = Math.min(this.defense * 0.05, 0.30); // Max 30%
    const dodged = Math.random() < dodgeChance;
    
    if (dodged) {
        return { killed: false, dodged: true };
    }
    
    this.health -= amount;
    if (this.health < 0) this.health = 0;
    return { killed: this.health <= 0, dodged: false };
}
2.3 Status Effects
Status Effect Types:

Poison (from zombie attacks, traps)

Duration: 5 turns
Effect: -1 HP per turn
Visual: Green tint on player
Burn (from dragon fire)

Duration: 3 turns
Effect: -2 HP per turn
Visual: Red/orange tint
Stun (from troll attacks)

Duration: 1 turn
Effect: Skip next turn
Chance: 20% on troll hit
Implementation in 
player.js
:

constructor() {
    // ... existing code ...
    this.statusEffects = {
        poison: { active: false, duration: 0 },
        burn: { active: false, duration: 0 },
        stun: { active: false, duration: 0 }
    };
}
applyStatusEffect(type, duration) {
    this.statusEffects[type] = { active: true, duration: duration };
}
processStatusEffects() {
    // Process poison
    if (this.statusEffects.poison.active) {
        this.takeDamage(1);
        this.statusEffects.poison.duration--;
        if (this.statusEffects.poison.duration <= 0) {
            this.statusEffects.poison.active = false;
        }
    }
    
    // Process burn
    if (this.statusEffects.burn.active) {
        this.takeDamage(2);
        this.statusEffects.burn.duration--;
        if (this.statusEffects.burn.duration <= 0) {
            this.statusEffects.burn.active = false;
        }
    }
    
    // Stun is handled in game loop
}
3. Expanded Scroll System
Goal: Add more tactical options through diverse scroll effects.

New Scroll Types
1. Scroll of Fireball
Effect: Deals 15 damage in 2-tile radius around target point
Usage: Player selects direction, fireball travels 5 tiles
Cost: Rare (10% spawn chance)
2. Scroll of Freeze
Effect: Stuns all enemies in 3-tile radius for 2 turns
Usage: Instant, centered on player
Cost: Rare (10% spawn chance)
3. Scroll of Haste
Effect: Double movement speed for 10 turns
Usage: Instant buff
Cost: Uncommon (15% spawn chance)
4. Scroll of Identify
Effect: Reveals all items on current level
Usage: Instant, shows item locations on map
Cost: Common (20% spawn chance)
5. Scroll of Mapping
Effect: Reveals entire dungeon map (fog of war removed)
Usage: Instant
Cost: Rare (10% spawn chance)
6. Scroll of Summon
Effect: Summons a friendly kobold to fight for you (5 turns)
Usage: Instant, spawns ally near player
Cost: Uncommon (15% spawn chance)
Implementation in 
item.js
:

// Add new scroll types to item definitions
const scrollTypes = {
    scroll_fireball: { name: 'Scroll of Fireball', effect: 'fireball' },
    scroll_freeze: { name: 'Scroll of Freeze', effect: 'freeze' },
    scroll_haste: { name: 'Scroll of Haste', effect: 'haste' },
    scroll_identify: { name: 'Scroll of Identify', effect: 'identify' },
    scroll_mapping: { name: 'Scroll of Mapping', effect: 'mapping' },
    scroll_summon: { name: 'Scroll of Summon', effect: 'summon' }
};
Implementation in 
game.js
 handleScrollEffect():

Add cases for each new scroll type
Implement effect logic
Display appropriate messages
4. Special Rooms
Goal: Add variety to dungeon exploration with unique room types.

Room Types
1. Treasure Room (5% chance)
Contents: 3-5 items (weapons, armor, potions)
Guardians: 2 elite monsters (higher stats)
Visual: Gold floor tiles or special marker
2. Trap Room (10% chance)
Contents: Multiple traps (3-5)
Reward: Rare scroll guaranteed
Visual: Warning symbol or darker tiles
3. Monster Nest (8% chance)
Contents: 2x normal monster count
Reward: 2x gold drops from monsters
Visual: Darker, cramped appearance
4. Shrine (3% chance)
Contents: Healing shrine (one-time use)
Effect: Heal to full HP + cure status effects
Visual: Glowing tile or special symbol
5. Library (5% chance)
Contents: 2-3 scrolls guaranteed
Guardians: 1-2 skeletons
Visual: Bookshelf symbols
6. Armory (5% chance)
Contents: 2 weapons/armor guaranteed
Guardians: 1-2 orcs
Visual: Weapon rack symbols
Implementation in 
dungeon.js
:

generate() {
    // ... existing room generation ...
    
    // Mark special rooms
    this.rooms.forEach((room, index) => {
        if (index === 0 || index === this.rooms.length - 1) {
            return; // Skip first and last rooms
        }
        
        const roomType = this.selectRoomType();
        if (roomType !== 'normal') {
            room.specialType = roomType;
            this.markSpecialRoom(room, roomType);
        }
    });
}
selectRoomType() {
    const rand = Math.random();
    if (rand < 0.03) return 'shrine';
    if (rand < 0.08) return 'treasure';
    if (rand < 0.13) return 'library';
    if (rand < 0.18) return 'armory';
    if (rand < 0.26) return 'monster_nest';
    if (rand < 0.36) return 'trap_room';
    return 'normal';
}
Implementation in 
game.js
:

Check room type when entering
Spawn appropriate contents/guardians
Display room type message
Implementation Order
Boss Encounters (3-4 hours)

Add boss monster types to 
monster.js
Implement boss spawn logic in 
game.js
Add boss special abilities
Test each boss individually
Enhanced Combat - Critical Hits (1 hour)

Modify 
attackTarget()
 in 
player.js
 and 
monster.js
Add critical hit messages
Test critical hit rate
Enhanced Combat - Dodge (1 hour)

Modify 
takeDamage()
 in 
player.js
Add dodge messages
Test dodge chance scaling
Enhanced Combat - Status Effects (2 hours)

Add status effect tracking to 
player.js
Implement status effect processing
Add visual indicators
Test each status effect
Expanded Scrolls (2-3 hours)

Add new scroll types to 
item.js
Implement scroll effects in 
game.js
Test each scroll type
Special Rooms (3-4 hours)

Modify 
dungeon.js
 to mark special rooms
Implement room type logic in 
game.js
Add visual markers in 
renderer.js
Test each room type
Files to Modify
js/monster.js
Add 5 new boss monster types
Implement boss-specific AI behaviors
Add boss special ability methods
js/player.js
Modify 
attackTarget()
 for critical hits
Modify 
takeDamage()
 for dodge
Add status effect tracking and processing
js/game.js
Add boss spawn logic
Update combat messages for crits/dodges
Add new scroll effect handlers
Add special room logic
js/dungeon.js
Add special room selection
Mark special rooms on map
Add boss spawn position method
js/item.js
Add 6 new scroll types
Update scroll spawn logic
js/renderer.js
Add visual indicators for status effects
Add special room markers
Add boss visual distinction
Testing Checklist
Boss Encounters
 Bosses spawn on correct levels (3, 6, 9, 10, 12)
 Each boss has correct stats
 Boss special abilities work correctly
 Boss drops are guaranteed and appropriate
 Boss XP is awarded correctly
Enhanced Combat
 Critical hits occur at ~10% rate
 Critical damage is 2x normal
 Dodge chance scales with defense
 Dodge messages display correctly
 Poison deals 1 damage per turn for 5 turns
 Burn deals 2 damage per turn for 3 turns
 Stun prevents player action for 1 turn
Expanded Scrolls
 All 6 new scroll types spawn
 Each scroll effect works as intended
 Scroll messages are clear
 Scroll spawn rates are balanced
Special Rooms
 Each room type spawns at correct rate
 Room contents match room type
 Guardians spawn correctly
 Room messages display
Expected Outcomes
Before Phase 2
Combat is simple "bump to attack"
No boss encounters
Limited scroll variety (4 types)
All rooms are generic
After Phase 2
✅ Combat has tactical depth (crits, dodges, status effects)
✅ 5 memorable boss encounters
✅ 10 total scroll types (4 existing + 6 new)
✅ 6 special room types add variety
✅ More strategic decision-making
✅ Higher replayability
Risk Assessment
Medium Risk
Boss AI complexity (may need iteration)
Status effect balance (could be too punishing)
Special room spawn rates (need playtesting)
Low Risk
Critical hits (straightforward RNG)
Dodge mechanics (simple calculation)
New scrolls (similar to existing)
Mitigation
Implement bosses one at a time
Make status effects configurable (easy to tune)
Playtest special room rates and adjust
Keep old code commented for easy rollback
Estimated Time
Boss Encounters: 3-4 hours
Enhanced Combat: 4 hours
Expanded Scrolls: 2-3 hours
Special Rooms: 3-4 hours
Total: 12-15 hours of development

Success Criteria
Phase 2 will be considered successful when:

All 5 bosses spawn and function correctly
Combat feels more dynamic with crits/dodges
Status effects add strategic depth
New scrolls provide tactical options
Special rooms make exploration more interesting
No game-breaking bugs
Performance remains smooth